﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagementSystem
{
    
    class Program
    {
       
        static void Main(string[] args)
        {
            int noofStudents=0;
            string ID = "Admin";
            string Pswd = "Admin@123";
            String id, password;
            


            Console.WriteLine("-:ADMIN LOGIN:-");
            Console.Write("Enter ID: ");
            id = Console.ReadLine();
            Console.WriteLine();
            Console.Write("Enter Password: ");
            password = Console.ReadLine();
            Console.WriteLine();
            
            if (id==ID && password == Pswd)
            {
                Console.WriteLine("Enter no of Students");
                noofStudents = int.Parse(Console.ReadLine());
                StudentReportCard[] ob = new StudentReportCard[noofStudents];
                for (int i = 0; i < noofStudents; i++)
                {
                    ob[i] = new StudentReportCard();
                    Console.WriteLine("------------------------------------");
                    Console.WriteLine("Enter the details of Student {0}", (i + 1));
                    ob[i].getDetails(); ;
                    ob[i].getResult();
                }

                while (true)
                {
                    Console.WriteLine("\n:MENU:================");
                    Console.WriteLine("1. Display Details");
                    Console.WriteLine("2. Student Average");
                    Console.WriteLine("3. Search Student by RollNumber");
                    Console.WriteLine("4. Delete a Student (by Roll number)");
                    Console.WriteLine("9. Exit");
                    Console.WriteLine("========================");
                    Console.WriteLine("Enter your choice");
                    int ch = int.Parse(Console.ReadLine());

                    switch (ch)
                    {
                        case 1:
                            for (int i = 0; i < ob.Length; i++)
                            {
                                ob[i].display();
                            }
                            break;

                        case 2:
                            StudentAnalysis result = new StudentAnalysis();
                            result.ClsAvg(ob, noofStudents);
                            break;

                        case 9:
                            System.Environment.FailFast("End");
                            break;

                        case 3:
                            Console.WriteLine("Enter the Student Roll number to be Found");
                            int idx = int.Parse(Console.ReadLine());
                            StudentAnalysis S = new StudentAnalysis();
                            S.SearchStudentByRoll(ob, idx);
                            break;

                        case 4:
                            Console.WriteLine("Enter the Student Roll number to be Delete");
                            int key = int.Parse(Console.ReadLine());
                            StudentAnalysis D = new StudentAnalysis();
                            D.deleteStudent(ob,key);
                            break;


                        default:
                            Console.WriteLine("Invalid Entry");
                            break;
                    }
                }
                
               /* for (int i = 0; i < ob.Length; i++)
                {
                    ob[i].display();
                }
                Console.WriteLine("\nWant to see the class Average?");

                ResultDeclare r = new ResultDeclare();
                r.ClsAvg(ob, noofStudents);*/
            }
            else
            {
                Console.WriteLine("Invalid ID or Password, Try Later");
            }

            
        }
    }
}
