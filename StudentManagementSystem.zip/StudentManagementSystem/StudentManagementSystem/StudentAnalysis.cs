﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagementSystem
{
    class StudentAnalysis:StudentReportCard
    {
        public void ClsAvg(StudentReportCard[] S, int noofstdnt)
        {
            
            float classAvg = 0;
            int count = 0;

            for (int i = 0; i < noofstdnt; i++)
            {
                    classAvg += S[i].AVG;
                    count++;
            }

            classAvg = classAvg / count;
            Console.WriteLine("=======================================");
            Console.WriteLine("The Average of the class is: "+classAvg+"%");
        }

        public void deleteStudent(StudentReportCard[] S, int index)
        {
            int idx = 0;
            for (int i = 0; i < S.Length; i++)
            {
                if (S[i].roll == index)
                {
                    Console.WriteLine("--------------");
                    Console.WriteLine("Found at: " + (i + 1));
                    idx = i;
                }

            }

            for (int i = idx; i < S.Length-1; i++)
            {
                S[i]= S[i + 1];
            }

            Console.WriteLine("Student Roll number: "+idx+" details are deleted");
            Console.WriteLine("---------------------------------");
            for(int i = 0; i < S.Length - 1; i++)
            {
                S[i].display();
            }
        }

        public void SearchStudentByRoll(StudentReportCard[] S, int key)
        {
            
            for(int i = 0; i < S.Length; i++)
            {
                if (S[i].roll == key)
                {
                    Console.WriteLine("--------------");
                    Console.WriteLine("Found at: "+(i+1));
                    S[i].display();   
                }
                else if(S[i]==null)
                    Console.WriteLine("There are no details available");

            }
        }

    }
}
