﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagementSystem
{
    abstract class StudentDetails
    {
        public static int noofSub = 6;
        public int roll, age, ProjectMarks;
        public int[] marks = new int[noofSub];
        public string name, course, email, contactNo, response;
        public float total,Score;
        private float avg;
        private int fees;

        public float AVG
        {
            set {avg = value;}
            get {return avg;}
        }

        public int Fees
        {
            set {fees = value;}
            get {return fees;}
        }
        public enum branch
        {
            ComputerScience = 1,
            Electronics = 2,
            Electrical = 3,
            Mechanical = 4
        };


        public void getData()
        {
            Console.WriteLine("Enter Roll Number: ");
            roll = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter name: ");
            name = Console.ReadLine();
            Console.WriteLine("Enter age:");
            age = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Email Id");
            email = Console.ReadLine();
            Console.WriteLine("Enter Contact Number");
            contactNo = Console.ReadLine();
            Console.WriteLine("Enter the fees paid");
            Fees = int.Parse(Console.ReadLine());
            Console.WriteLine("====================================");
            foreach (branch b in Enum.GetValues(typeof(branch)))
            {
                Console.WriteLine(b);
            }
            Console.WriteLine("====================================");
            Console.WriteLine("Select course from above options");
            course = Console.ReadLine();
        }

        public void display()
        {
            Console.WriteLine("====================================");
            Console.Write("Roll No: "+roll+"\n");
            Console.Write("Name: "+name+"\n");
            Console.Write("Age: " + age + "\n");
            Console.Write("Email Address: " + email + "\n");
            Console.Write("Contact Number: " + contactNo + "\n");
            Console.WriteLine("Fees paid: "+Fees);
            Console.Write("Course Name: " + course + "\n");
            if (response == "Y" || response == "y")
            {
                for (int i = 0; i < noofSub; i++)
                {
                    Console.WriteLine("Subject {0}: {1}", (i + 1), marks[i]);
                    total += marks[i];
                }
                Console.WriteLine();
                Console.WriteLine("Score: " + Score + "/" + (100 * (noofSub + 1)));
                Console.WriteLine("The AVERAGE Score is: " + avg + "%");
            }
            else if (response == "N" || response == "n")
            {
                for (int i = 0; i < noofSub; i++)
                {
                    Console.WriteLine("Subject {0}: {1}", (i + 1), marks[i]);
                    
                }
                Console.WriteLine("Score: " + total + "/" + (100 * noofSub));
                Console.WriteLine("The AVERAGE Score is: " + avg + "%");
            }
            

            try
            {
                for(int i = 0; i < noofSub; i++)
                {
                    if (marks[i] > 100)
                    {
                        Console.WriteLine("Invalid input");
                    }
                }
                if (avg > 100)
                {
                    Console.WriteLine("Something is wrong, please check again");
                }
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            
            Console.WriteLine("====================================");
        }

        public abstract void Course();
        public abstract void Calculate();
        public abstract void Calculate(int ProjectMarks);

    }

    class Implementation : StudentDetails
    {
        public override void Calculate()
        {
            int noofSub = 6;
            
            Console.WriteLine("Enter the 6 subjects marks");
            for (int i = 0; i < noofSub; i++)
                marks[i] = int.Parse(Console.ReadLine());

            for(int i = 0; i < noofSub; i++)
            {
                total += marks[i];
            }
            AVG = total / noofSub;
        }

        public override void Calculate(int ProjectMarks)
        {
            int noofSub = 6;
            Console.WriteLine("Enter the 6 subjects marks");
            for (int i = 0; i < noofSub; i++)
                marks[i] = int.Parse(Console.ReadLine());

            for (int i = 0; i < noofSub; i++)
            {
                Console.WriteLine("Subject {0}: {1}", (i + 1), marks[i]);
                total += marks[i];
            }
            
            Console.Write("Enter Project Marks out of 100: ");
            ProjectMarks = int.Parse(Console.ReadLine());
            Console.WriteLine();
            Score = total + ProjectMarks;
            AVG = (Score) / (noofSub + 1);
        }


        public override void Course()
        {
            int flag = 1;
            
            foreach(string b in Enum.GetNames(typeof(branch)))
            {
                if (course == b)
                {
                    Console.WriteLine("Have you done Project? Y:N");
                    response = Console.ReadLine();
                    switch (b)
                    {
                        case "ComputerScience":
                            if (response == "Y" || response == "y")
                                Calculate(ProjectMarks);
                            else
                                Calculate();
                            break;

                        case "Electronics":
                            if (response == "Y" || response == "y")
                                Calculate(ProjectMarks);
                            else
                                Calculate();
                            break;

                        case "Electrical":
                            if (response == "Y" || response == "y")
                                Calculate(ProjectMarks);
                            else
                                Calculate();
                            break;

                        case "Mechanical":
                            if (response == "Y" || response == "y")
                                Calculate(ProjectMarks);
                            else
                                Calculate();
                            break;

                        default:
                            Console.WriteLine("Invalid Branch.");
                            break;
                    }

                }
                else
                {
                    flag = 0;
                    //System.Environment.FailFast("Branch not available or Enter Branch name as specified above");
                }

            }
            
            
        }
    }

    interface IGetStudentDetails
    {
        void getDetails();
    }

    interface IGetStudentAcademics
    {
        void getResult();
    }
    class StudentReportCard:Implementation,IGetStudentDetails,IGetStudentAcademics
    {
        
        public void getDetails()
        {
            base.getData();    
        }
        public void getResult()
        {
            base.Course();  
        }
    }
}
